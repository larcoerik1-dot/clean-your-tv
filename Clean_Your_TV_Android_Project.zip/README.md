# Clean Your TV

Starter project for an Android TV / Google TV utility app.

## Included in version 1.0
- Dark dashboard designed for TV screens.
- Reads available RAM using Android's ActivityManager.
- Reads app data partition storage statistics.
- Counts launchable apps visible to the package manager.
- Opens Android system settings for storage and app management.
- Basic GitHub Actions workflow to build a debug APK in the cloud.

## Build
Requires JDK 17 and Gradle 8.11.1:
```bash
gradle assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Important Android limitations
Android does not let ordinary third-party apps silently clear another app's cache or arbitrarily kill background processes. This starter opens official system settings instead. Storage numbers are for the `/data` partition and may differ from the TV's user-facing storage screen.

## Cloud build
Upload this project to a GitHub repository. Open Actions and run "Build Clean Your TV APK". Download the `Clean-Your-TV-debug` artifact when the workflow finishes.
