package com.cleanyourtv.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.util.Locale

private val Navy = Color(0xFF080E18)
private val Panel = Color(0xFF121F30)
private val Blue = Color(0xFF45B5FF)
private val Green = Color(0xFF39D69A)
private val Muted = Color(0xFF9EB0C5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CleanYourTvApp() }
    }
}

@Composable
fun CleanYourTvApp() {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val storage = remember(refresh) { readStorage() }
    val memory = remember(refresh) { readMemory(context as Activity) }
    val appCount = remember(refresh) { readLaunchableApps(context as Activity) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy,
            surface = Panel,
            primary = Blue,
            secondary = Green
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Column(
                modifier = Modifier.fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 28.dp, vertical = 22.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tv, null, tint = Blue, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("CLEAN YOUR TV", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Panel de diagnóstico", color = Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("v1.0", color = Muted, fontSize = 12.sp)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ESTADO DEL DISPOSITIVO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Tu TV está listo", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Consulta los datos reales de almacenamiento y memoria.", color = Muted, fontSize = 14.sp)
                    }
                }

                Text("INFORMACIÓN DEL SISTEMA", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    InfoCard("Almacenamiento", storage, Icons.Default.Storage, Modifier.weight(1f))
                    InfoCard("RAM disponible", memory, Icons.Default.Memory, Modifier.weight(1f))
                }
                InfoCard("Aplicaciones visibles", "$appCount", Icons.Default.Apps, Modifier.fillMaxWidth())

                Text("HERRAMIENTAS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                ActionCard(
                    "Revisar almacenamiento",
                    "Abre los ajustes oficiales para administrar espacio",
                    Icons.Default.CleaningServices
                ) {
                    runCatching { context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
                        .onFailure { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                }
                ActionCard(
                    "Administrar aplicaciones",
                    "Consulta y desinstala aplicaciones desde Android",
                    Icons.Default.AppSettingsAlt
                ) {
                    context.startActivity(Intent(Settings.ACTION_SETTINGS))
                }
                ActionCard(
                    "Actualizar diagnóstico",
                    "Vuelve a consultar los datos del dispositivo",
                    Icons.Default.Refresh
                ) { refresh++ }

                Text(
                    "Nota: Android no permite que esta aplicación borre la caché de otras apps ni cierre procesos arbitrariamente. Clean Your TV utiliza herramientas oficiales del sistema.",
                    color = Muted, fontSize = 12.sp, lineHeight = 17.sp
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(25.dp))
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .border(if (focused) 2.dp else 1.dp, if (focused) Blue else Color(0xFF26384D), RoundedCornerShape(16.dp))
            .focusable(),
        colors = CardDefaults.cardColors(containerColor = if (focused) Color(0xFF1A3551) else Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(27.dp))
            Spacer(Modifier.width(15.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

private fun readStorage(): String = runCatching {
    val stat = StatFs(File("/data").path)
    val total = stat.totalBytes.toDouble()
    val free = stat.availableBytes.toDouble()
    val used = total - free
    "${formatGb(used)} usados"
}.getOrDefault("No disponible")

private fun readMemory(activity: Activity): String = runCatching {
    val manager = activity.getSystemService(ActivityManager::class.java)
    val info = ActivityManager.MemoryInfo()
    manager.getMemoryInfo(info)
    "${formatGb(info.availMem)} libres"
}.getOrDefault("No disponible")

private fun readLaunchableApps(activity: Activity): Int = runCatching {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    activity.packageManager.queryIntentActivities(intent, 0).size
}.getOrDefault(0)

private fun formatGb(bytes: Long): String =
    String.format(Locale.getDefault(), "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0))
